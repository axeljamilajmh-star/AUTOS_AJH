﻿using System;
using System.Collections.Generic;

namespace Autos_AJMH.Models
{
    public class Vehiculo
    {
        public string Codigo { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int Anio { get; set; }
        public string Tipo { get; set; }
        public double Precio { get; set; }
        public int UnidadesDisponibles { get; set; }
        public double Cilindraje { get; set; }
        public string Categoria { get; set; }
        public List<string> Fotos { get; set; }
        public bool Vendido { get; set; }  

        public Vehiculo()
        {
            Fotos = new List<string>();
        }
    }
}
