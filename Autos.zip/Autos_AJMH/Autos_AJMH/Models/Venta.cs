﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autos_AJMH.Models
{
    public class Venta
    {
        public string CodigoVenta { get; set; }
        public string CodigoVehiculo { get; set; }
        public DateTime FechaVenta { get; set; }
        public double Monto { get; set; }
    }
}
