﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Autos_AJMH.View
{
    public partial class Dg : Form
    {
        public Dg()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {
            FrmRegistrarVenta frm = new FrmRegistrarVenta
            {
                MdiParent = this // Se abre dentro del FrmGestionVentas
            };
            frm.Show();
        }

        private void Dg_Load(object sender, EventArgs e)
        {
            FrmDescuento frm = new FrmDescuento
            {
                MdiParent = this
            };
            frm.Show();
        }

        public static implicit operator Dg(FrmMenuPrincipal v)
        {
            throw new NotImplementedException();
        }
    }
}
