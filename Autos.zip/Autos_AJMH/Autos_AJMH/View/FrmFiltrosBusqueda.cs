﻿using Autos_AJMH.Controllers;
using Autos_AJMH.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Autos_AJMH.View
{
    public partial class FrmFiltrosBusqueda : Form
    {
        private readonly VehiculoController vehiculoController;

        public FrmFiltrosBusqueda()
        {
            InitializeComponent();
            vehiculoController = new VehiculoController();
        }
        private void FrmFiltrosBusqueda_Load(object sender, EventArgs e)
        {
            dgvResultados.DataSource = vehiculoController.ListarVehiculos();
        }
        private void BtnBuscarModeloAnio_Click(object sender, EventArgs e)
        {
            string modelo = txtModelo.Text.Trim();
            int anio = (int)numAnio.Value;

            if (string.IsNullOrWhiteSpace(modelo))
            {
                MessageBox.Show("Ingrese un modelo para buscar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<Vehiculo> resultados = vehiculoController.FiltrarPorModeloYAño(modelo, anio);

            if (resultados.Count == 0)
            {
                MessageBox.Show("No se encontraron vehículos con esos criterios.", "Sin resultados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            dgvResultados.DataSource = null;
            dgvResultados.DataSource = resultados;
        }
        private void BtnBuscarPrecioCat_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(numMin.Text, out double min))
            {
                MessageBox.Show("Ingrese un valor mínimo válido.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!double.TryParse(numMax.Text, out double max))
            {
                MessageBox.Show("Ingrese un valor máximo válido.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string categoria = txtCategoria.Text.Trim();

            if (string.IsNullOrWhiteSpace(categoria))
            {
                MessageBox.Show("Ingrese una categoría.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<Vehiculo> resultados = vehiculoController.FiltrarPorPrecioYCategoria(min, max, categoria);

            if (resultados.Count == 0)
            {
                MessageBox.Show("No se encontraron vehículos con esos criterios.", "Sin resultados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            dgvResultados.DataSource = null;
            dgvResultados.DataSource = resultados;
        }

        
    }

}

