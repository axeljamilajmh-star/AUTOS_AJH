﻿using Autos_AJMH.Controllers;
using Autos_AJMH.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Autos_AJMH.View
{
    public partial class FrmListadoVehiculos : Form
    {
        private readonly VehiculoController VehiculoController;

        public FrmListadoVehiculos()
        {
            InitializeComponent();
            VehiculoController = new VehiculoController();
        }

        private void FrmListadoVehiculos_Load(object sender, EventArgs e)
        {
            CargarVehiculos();
        }

        private void CargarVehiculos(List<Vehiculo> lista = null)
        {
            dgvVehiculos.DataSource = null;
            dgvVehiculos.DataSource = lista ?? VehiculoController.ListarVehiculos();
        }

        private VehiculoController GetVehiculoController()
        {
            return VehiculoController;
        }

        private void BtnOrdenarMarca_Click(object sender, EventArgs e)
        {
            if (!(VehiculoController.ListarVehiculos() is List<Vehiculo> lista))
                return;
            var listaOrdenada = lista.OrderBy(v => v.Marca).ToList();
            CargarVehiculos(listaOrdenada);
        }

        private void BtnOrdenarModelo_Click(object sender, EventArgs e)
        {
            if (!(VehiculoController.ListarVehiculos() is List<Vehiculo> lista))
                return;
            var listaOrdenada = lista.OrderBy(v => v.Modelo).ToList();
            CargarVehiculos(listaOrdenada);
        }

        private void BtnOrdenarAnio_Click(object sender, EventArgs e)
        {
            if (!(VehiculoController.ListarVehiculos() is List<Vehiculo> lista))
                return;
            var listaOrdenada = lista.OrderBy(v => v.Anio).ToList();
            CargarVehiculos(listaOrdenada);
        }
    }
}
