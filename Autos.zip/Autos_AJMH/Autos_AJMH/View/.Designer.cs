﻿using System;

namespace Autos_AJMH.View
{
    partial class FrmMenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.vehiculosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaDeVehiculoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detalleVehiculoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarVehiculoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inventarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filtrosDeBusquedadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrarVentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descuntoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descuentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vehículoMásAntiguoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vehículoConMayorCilindrajeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vehículoConPrecioMásBajoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vehiculosToolStripMenuItem,
            this.inventarioToolStripMenuItem,
            this.ventasToolStripMenuItem,
            this.descuentoToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // vehiculosToolStripMenuItem
            // 
            this.vehiculosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listaDeVehiculoToolStripMenuItem,
            this.detalleVehiculoToolStripMenuItem,
            this.agregarVehiculoToolStripMenuItem});
            this.vehiculosToolStripMenuItem.Name = "vehiculosToolStripMenuItem";
            this.vehiculosToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.vehiculosToolStripMenuItem.Text = "Vehiculos";
            // 
            // listaDeVehiculoToolStripMenuItem
            // 
            this.listaDeVehiculoToolStripMenuItem.Name = "listaDeVehiculoToolStripMenuItem";
            this.listaDeVehiculoToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.listaDeVehiculoToolStripMenuItem.Text = "Lista de vehiculo";
            this.listaDeVehiculoToolStripMenuItem.Click += new System.EventHandler(this.ListaDeVehiculoToolStripMenuItem_Click);
            // 
            // detalleVehiculoToolStripMenuItem
            // 
            this.detalleVehiculoToolStripMenuItem.Name = "detalleVehiculoToolStripMenuItem";
            this.detalleVehiculoToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.detalleVehiculoToolStripMenuItem.Text = "Detalle vehiculo";
            this.detalleVehiculoToolStripMenuItem.Click += new System.EventHandler(this.DetalleVehiculoToolStripMenuItem_Click);
            // 
            // agregarVehiculoToolStripMenuItem
            // 
            this.agregarVehiculoToolStripMenuItem.Name = "agregarVehiculoToolStripMenuItem";
            this.agregarVehiculoToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.agregarVehiculoToolStripMenuItem.Text = "Agregar vehiculo";
            this.agregarVehiculoToolStripMenuItem.Click += new System.EventHandler(this.AgregarVehiculoToolStripMenuItem_Click);
            // 
            // inventarioToolStripMenuItem
            // 
            this.inventarioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filtrosDeBusquedadToolStripMenuItem});
            this.inventarioToolStripMenuItem.Name = "inventarioToolStripMenuItem";
            this.inventarioToolStripMenuItem.Size = new System.Drawing.Size(89, 24);
            this.inventarioToolStripMenuItem.Text = "Inventario";
            // 
            // filtrosDeBusquedadToolStripMenuItem
            // 
            this.filtrosDeBusquedadToolStripMenuItem.Name = "filtrosDeBusquedadToolStripMenuItem";
            this.filtrosDeBusquedadToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.filtrosDeBusquedadToolStripMenuItem.Text = "Filtros de busquedad";
            this.filtrosDeBusquedadToolStripMenuItem.Click += new System.EventHandler(this.FiltrosDeBusquedadToolStripMenuItem_Click);
            // 
            // ventasToolStripMenuItem
            // 
            this.ventasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrarVentasToolStripMenuItem,
            this.descuntoToolStripMenuItem});
            this.ventasToolStripMenuItem.Name = "ventasToolStripMenuItem";
            this.ventasToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.ventasToolStripMenuItem.Text = "Ventas";
            // 
            // registrarVentasToolStripMenuItem
            // 
            this.registrarVentasToolStripMenuItem.Name = "registrarVentasToolStripMenuItem";
            this.registrarVentasToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.registrarVentasToolStripMenuItem.Text = "Registrar venta";
            this.registrarVentasToolStripMenuItem.Click += new System.EventHandler(this.RegistrarVentaToolStripMenuItem_Click);
            // 
            // descuntoToolStripMenuItem
            // 
            this.descuntoToolStripMenuItem.Name = "descuntoToolStripMenuItem";
            this.descuntoToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.descuntoToolStripMenuItem.Text = "Descuento";
            this.descuntoToolStripMenuItem.Click += new System.EventHandler(this.descuntoToolStripMenuItem_Click);
            // 
            // descuentoToolStripMenuItem
            // 
            this.descuentoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vehículoMásAntiguoToolStripMenuItem,
            this.vehículoConMayorCilindrajeToolStripMenuItem,
            this.vehículoConPrecioMásBajoToolStripMenuItem});
            this.descuentoToolStripMenuItem.Name = "descuentoToolStripMenuItem";
            this.descuentoToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.descuentoToolStripMenuItem.Text = "Consultas";
            // 
            // vehículoMásAntiguoToolStripMenuItem
            // 
            this.vehículoMásAntiguoToolStripMenuItem.Name = "vehículoMásAntiguoToolStripMenuItem";
            this.vehículoMásAntiguoToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.vehículoMásAntiguoToolStripMenuItem.Text = "Vehículo más antiguo";
            // 
            // vehículoConMayorCilindrajeToolStripMenuItem
            // 
            this.vehículoConMayorCilindrajeToolStripMenuItem.Name = "vehículoConMayorCilindrajeToolStripMenuItem";
            this.vehículoConMayorCilindrajeToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.vehículoConMayorCilindrajeToolStripMenuItem.Text = "Vehículo con mayor cilindraje";
            // 
            // vehículoConPrecioMásBajoToolStripMenuItem
            // 
            this.vehículoConPrecioMásBajoToolStripMenuItem.Name = "vehículoConPrecioMásBajoToolStripMenuItem";
            this.vehículoConPrecioMásBajoToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.vehículoConPrecioMásBajoToolStripMenuItem.Text = "Vehículo con precio más bajo";
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(52, 24);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.SalirToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // FrmMenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmMenuPrincipal";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FrmMenuPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void descuntoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void registrarVentasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();

        }

        private void FrmMenuPrincipal_Load(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem vehiculosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inventarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem descuentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem listaDeVehiculoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem detalleVehiculoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarVehiculoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filtrosDeBusquedadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrarVentasToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem descuntoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vehículoMásAntiguoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vehículoConMayorCilindrajeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vehículoConPrecioMásBajoToolStripMenuItem;
    }
}