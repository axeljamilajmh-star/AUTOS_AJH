﻿using System;

namespace Autos_AJMH.View
{
    internal class FrmDescuento
    {
        public Dg MdiParent { get; internal set; }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}