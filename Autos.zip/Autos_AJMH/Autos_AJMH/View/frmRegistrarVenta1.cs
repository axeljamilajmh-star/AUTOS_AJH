﻿namespace Autos_AJMH.View
{
    internal class frmRegistrarVenta
    {
    }
}