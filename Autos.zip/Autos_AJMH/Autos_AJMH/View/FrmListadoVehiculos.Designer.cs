﻿namespace Autos_AJMH.View
{
    partial class FrmListadoVehiculos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvVehiculos = new System.Windows.Forms.DataGridView();
            this.btnOrdenarMarca = new System.Windows.Forms.Button();
            this.btnOrdenarModelo = new System.Windows.Forms.Button();
            this.btnOrdenarAnio = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVehiculos)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvVehiculos
            // 
            this.dgvVehiculos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVehiculos.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvVehiculos.Location = new System.Drawing.Point(0, 0);
            this.dgvVehiculos.Name = "dgvVehiculos";
            this.dgvVehiculos.RowHeadersWidth = 51;
            this.dgvVehiculos.RowTemplate.Height = 24;
            this.dgvVehiculos.Size = new System.Drawing.Size(800, 307);
            this.dgvVehiculos.TabIndex = 0;
            // 
            // btnOrdenarMarca
            // 
            this.btnOrdenarMarca.Location = new System.Drawing.Point(33, 313);
            this.btnOrdenarMarca.Name = "btnOrdenarMarca";
            this.btnOrdenarMarca.Size = new System.Drawing.Size(159, 23);
            this.btnOrdenarMarca.TabIndex = 1;
            this.btnOrdenarMarca.Text = "Ordenar por Marca";
            this.btnOrdenarMarca.UseVisualStyleBackColor = true;
            // 
            // btnOrdenarModelo
            // 
            this.btnOrdenarModelo.Location = new System.Drawing.Point(256, 313);
            this.btnOrdenarModelo.Name = "btnOrdenarModelo";
            this.btnOrdenarModelo.Size = new System.Drawing.Size(159, 23);
            this.btnOrdenarModelo.TabIndex = 2;
            this.btnOrdenarModelo.Text = "Ordenar por Modelo";
            this.btnOrdenarModelo.UseVisualStyleBackColor = true;
            // 
            // btnOrdenarAnio
            // 
            this.btnOrdenarAnio.Location = new System.Drawing.Point(488, 313);
            this.btnOrdenarAnio.Name = "btnOrdenarAnio";
            this.btnOrdenarAnio.Size = new System.Drawing.Size(159, 23);
            this.btnOrdenarAnio.TabIndex = 3;
            this.btnOrdenarAnio.Text = "Ordenar por Año";
            this.btnOrdenarAnio.UseVisualStyleBackColor = true;
            // 
            // FrmListadoVehiculos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnOrdenarAnio);
            this.Controls.Add(this.btnOrdenarModelo);
            this.Controls.Add(this.btnOrdenarMarca);
            this.Controls.Add(this.dgvVehiculos);
            this.Name = "FrmListadoVehiculos";
            this.Text = "FrmListadoVehiculos";
            this.Load += new System.EventHandler(this.FrmListadoVehiculos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVehiculos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvVehiculos;
        private System.Windows.Forms.Button btnOrdenarMarca;
        private System.Windows.Forms.Button btnOrdenarModelo;
        private System.Windows.Forms.Button btnOrdenarAnio;
    }
}