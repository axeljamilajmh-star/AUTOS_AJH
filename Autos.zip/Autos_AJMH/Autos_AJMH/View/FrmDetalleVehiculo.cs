﻿using Autos_AJMH.Controllers;
using Autos_AJMH.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Autos_AJMH.View
{
    
    public partial class FrmDetalleVehiculo : Form
    {
        // Solución para IDE0044: Hacer el campo de solo lectura
        // Solo se requiere agregar 'readonly' a los campos que no cambian después de la inicialización.

        private readonly VehiculoController controller = new VehiculoController();
        // Cambia el tipo de grpDetalle de object a GroupBox (o el tipo real del control)
        private readonly GroupBox grpDetalle;

        public FrmDetalleVehiculo()
        {
            InitializeComponent();
            grpDetalle = groupBox1; // asignación válida para readonly en el constructor
        }


        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            string codigo = txtCodigo.Text;

            // 💡 Llama al método de instancia correcto
            Vehiculo vehiculo = controller.BuscarPorCodigo(codigo);

            if (vehiculo == null)
            {
                MessageBox.Show("No se encontró ningún vehículo con ese código.", "Sin resultados", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                groupBox1.Enabled = false;
                return;
            }

            // Si se encuentra, el resto del código funciona
            groupBox1.Enabled = true;
            lblMarca.Text = $"Marca: {vehiculo.Marca}";
            lblModelo.Text = $"Modelo: {vehiculo.Modelo}";
            lblAnio.Text = $"Año: {vehiculo.Anio}";
            lblTipo.Text = $"Tipo: {vehiculo.Tipo}";
            lblPrecio.Text = $"Precio: {vehiculo.Precio}";

            // Aquí iría la carga de la imagen (picFoto)
        }

        private void FrmDetalleVehiculo_Load(object sender, EventArgs e)
        {

        }
    }
}
