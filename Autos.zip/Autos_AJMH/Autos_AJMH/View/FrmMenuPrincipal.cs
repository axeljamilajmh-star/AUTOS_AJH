﻿using Autos_AJMH.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Autos_AJMH.View
{
    public partial class FrmMenuPrincipal : Form
    {
        public FrmMenuPrincipal()
        {
            InitializeComponent();
        }
        private void ListarVehículosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmListadoVehiculos frm = new FrmListadoVehiculos();
            frm.ShowDialog();
        }

        private void DetallePorCódigoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmDetalleVehiculo frm = new FrmDetalleVehiculo();
            frm.ShowDialog();
        }

        private void AgregarVehículoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAgregarVehiculo frm = new FrmAgregarVehiculo();
            frm.ShowDialog();
        }

        private void FiltrosDeBúsquedaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmFiltrosBusqueda frm = new FrmFiltrosBusqueda();
            frm.ShowDialog();
        }

        private void AplicarDescuentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAplicarDescuento frm = new FrmAplicarDescuento();
            frm.ShowDialog();
        }

        private void ConsultasEspecialesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmConsultasEspeciales frm = new FrmConsultasEspeciales();
            frm.ShowDialog();
        }

        private void RegistrarVentaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmRegistrarVenta frm = new FrmRegistrarVenta
            {
                MdiParent = this   // Esto hace que se abra dentro del menú principal
            };
            frm.Show();
        }


        private void SalirDelSistemaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ListaDeVehiculoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmListadoVehiculos listado = new FrmListadoVehiculos();
            listado.ShowDialog();

        }

        private void AgregarVehiculoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAgregarVehiculo frm = new FrmAgregarVehiculo();
            frm.ShowDialog();

        }

        private void DetalleVehiculoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmDetalleVehiculo frm = new FrmDetalleVehiculo();
            frm.ShowDialog();

        }

        private void FiltrosDeBusquedadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmFiltrosBusqueda frm = new FrmFiltrosBusqueda();
            frm.ShowDialog();

        }

        private void SalirToolStripMenuItem_Click(object sender, EventArgs e)
        {
             Application.Exit();
        }
    }
}
