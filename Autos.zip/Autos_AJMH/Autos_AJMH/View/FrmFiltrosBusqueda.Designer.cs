﻿using System;

namespace Autos_AJMH.View
{
    partial class FrmFiltrosBusqueda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnFiltrarModeloAnio = new System.Windows.Forms.Button();
            this.numAnio = new System.Windows.Forms.NumericUpDown();
            this.lblAnio = new System.Windows.Forms.Label();
            this.txtModelo = new System.Windows.Forms.TextBox();
            this.lblModelo = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.grpPrecioCategoria = new System.Windows.Forms.GroupBox();
            this.btnFiltrarPrecioCat = new System.Windows.Forms.Button();
            this.txtCategoria = new System.Windows.Forms.TextBox();
            this.lblCat = new System.Windows.Forms.Label();
            this.numMax = new System.Windows.Forms.NumericUpDown();
            this.lblMax = new System.Windows.Forms.Label();
            this.numMin = new System.Windows.Forms.TextBox();
            this.lblMin = new System.Windows.Forms.Label();
            this.dgvResultados = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAnio)).BeginInit();
            this.grpPrecioCategoria.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnFiltrarModeloAnio);
            this.groupBox1.Controls.Add(this.numAnio);
            this.groupBox1.Controls.Add(this.lblAnio);
            this.groupBox1.Controls.Add(this.txtModelo);
            this.groupBox1.Controls.Add(this.lblModelo);
            this.groupBox1.Location = new System.Drawing.Point(23, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(361, 291);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "FILTRO POR MODELO Y AÑO";
            // 
            // btnFiltrarModeloAnio
            // 
            this.btnFiltrarModeloAnio.Location = new System.Drawing.Point(104, 183);
            this.btnFiltrarModeloAnio.Name = "btnFiltrarModeloAnio";
            this.btnFiltrarModeloAnio.Size = new System.Drawing.Size(128, 47);
            this.btnFiltrarModeloAnio.TabIndex = 4;
            this.btnFiltrarModeloAnio.Text = "BUSCAR";
            this.btnFiltrarModeloAnio.UseVisualStyleBackColor = true;
            // 
            // numAnio
            // 
            this.numAnio.Location = new System.Drawing.Point(76, 115);
            this.numAnio.Name = "numAnio";
            this.numAnio.Size = new System.Drawing.Size(165, 22);
            this.numAnio.TabIndex = 3;
            // 
            // lblAnio
            // 
            this.lblAnio.AutoSize = true;
            this.lblAnio.Location = new System.Drawing.Point(6, 121);
            this.lblAnio.Name = "lblAnio";
            this.lblAnio.Size = new System.Drawing.Size(36, 16);
            this.lblAnio.TabIndex = 2;
            this.lblAnio.Text = "AÑO";
            // 
            // txtModelo
            // 
            this.txtModelo.Location = new System.Drawing.Point(76, 59);
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.Size = new System.Drawing.Size(229, 22);
            this.txtModelo.TabIndex = 1;
            // 
            // lblModelo
            // 
            this.lblModelo.AutoSize = true;
            this.lblModelo.Location = new System.Drawing.Point(6, 62);
            this.lblModelo.Name = "lblModelo";
            this.lblModelo.Size = new System.Drawing.Size(64, 16);
            this.lblModelo.TabIndex = 0;
            this.lblModelo.Text = "MODELO";
            // 
            // grpPrecioCategoria
            // 
            this.grpPrecioCategoria.Controls.Add(this.btnFiltrarPrecioCat);
            this.grpPrecioCategoria.Controls.Add(this.txtCategoria);
            this.grpPrecioCategoria.Controls.Add(this.lblCat);
            this.grpPrecioCategoria.Controls.Add(this.numMax);
            this.grpPrecioCategoria.Controls.Add(this.lblMax);
            this.grpPrecioCategoria.Controls.Add(this.numMin);
            this.grpPrecioCategoria.Controls.Add(this.lblMin);
            this.grpPrecioCategoria.Location = new System.Drawing.Point(421, 48);
            this.grpPrecioCategoria.Name = "grpPrecioCategoria";
            this.grpPrecioCategoria.Size = new System.Drawing.Size(358, 291);
            this.grpPrecioCategoria.TabIndex = 1;
            this.grpPrecioCategoria.TabStop = false;
            this.grpPrecioCategoria.Text = "FILTRO POR PRECIO Y CATEGORIA";
            // 
            // btnFiltrarPrecioCat
            // 
            this.btnFiltrarPrecioCat.Location = new System.Drawing.Point(129, 183);
            this.btnFiltrarPrecioCat.Name = "btnFiltrarPrecioCat";
            this.btnFiltrarPrecioCat.Size = new System.Drawing.Size(111, 47);
            this.btnFiltrarPrecioCat.TabIndex = 6;
            this.btnFiltrarPrecioCat.Text = "BUSCAR";
            this.btnFiltrarPrecioCat.UseVisualStyleBackColor = true;
            // 
            // txtCategoria
            // 
            this.txtCategoria.Location = new System.Drawing.Point(154, 126);
            this.txtCategoria.Name = "txtCategoria";
            this.txtCategoria.Size = new System.Drawing.Size(182, 22);
            this.txtCategoria.TabIndex = 5;
            // 
            // lblCat
            // 
            this.lblCat.AutoSize = true;
            this.lblCat.Location = new System.Drawing.Point(28, 129);
            this.lblCat.Name = "lblCat";
            this.lblCat.Size = new System.Drawing.Size(85, 16);
            this.lblCat.TabIndex = 4;
            this.lblCat.Text = "CATEGORIA";
            // 
            // numMax
            // 
            this.numMax.Location = new System.Drawing.Point(154, 78);
            this.numMax.Name = "numMax";
            this.numMax.Size = new System.Drawing.Size(184, 22);
            this.numMax.TabIndex = 3;
            this.numMax.ValueChanged += new System.EventHandler(this.numMax_ValueChanged);
            // 
            // lblMax
            // 
            this.lblMax.AutoSize = true;
            this.lblMax.Location = new System.Drawing.Point(24, 80);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(112, 16);
            this.lblMax.TabIndex = 2;
            this.lblMax.Text = "PRECIO MAXIMO";
            this.lblMax.Click += new System.EventHandler(this.label1_Click);
            // 
            // numMin
            // 
            this.numMin.Location = new System.Drawing.Point(154, 40);
            this.numMin.Name = "numMin";
            this.numMin.Size = new System.Drawing.Size(185, 22);
            this.numMin.TabIndex = 1;
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Location = new System.Drawing.Point(24, 46);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(108, 16);
            this.lblMin.TabIndex = 0;
            this.lblMin.Text = "PRECIO MINIMO";
            // 
            // dgvResultados
            // 
            this.dgvResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados.Location = new System.Drawing.Point(99, 345);
            this.dgvResultados.Name = "dgvResultados";
            this.dgvResultados.RowHeadersWidth = 51;
            this.dgvResultados.RowTemplate.Height = 24;
            this.dgvResultados.Size = new System.Drawing.Size(552, 104);
            this.dgvResultados.TabIndex = 2;
            // 
            // FrmFiltrosBusqueda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvResultados);
            this.Controls.Add(this.grpPrecioCategoria);
            this.Controls.Add(this.groupBox1);
            this.Name = "FrmFiltrosBusqueda";
            this.Text = "FrmFiltrosBusqueda";
            this.Load += new System.EventHandler(this.FrmFiltrosBusqueda_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAnio)).EndInit();
            this.grpPrecioCategoria.ResumeLayout(false);
            this.grpPrecioCategoria.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).EndInit();
            this.ResumeLayout(false);

        }

        private void numMax_ValueChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.NumericUpDown numAnio;
        private System.Windows.Forms.Label lblAnio;
        private System.Windows.Forms.TextBox txtModelo;
        private System.Windows.Forms.Label lblModelo;
        private System.Windows.Forms.Button btnFiltrarModeloAnio;
        private System.Windows.Forms.GroupBox grpPrecioCategoria;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.Label lblMax;
        private System.Windows.Forms.TextBox numMin;
        private System.Windows.Forms.Label lblCat;
        private System.Windows.Forms.NumericUpDown numMax;
        private System.Windows.Forms.Button btnFiltrarPrecioCat;
        private System.Windows.Forms.TextBox txtCategoria;
        private System.Windows.Forms.DataGridView dgvResultados;
    }
}