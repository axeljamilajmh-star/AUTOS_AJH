﻿using System;

namespace Autos_AJMH.View
{
    internal class FrmRegistrarVenta
    {
        public Dg MdiParent { get; internal set; }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}