﻿using Autos_AJMH.Controllers;
using Autos_AJMH.Models;
using System;
using System.Windows.Forms;

namespace Autos_AJMH.View
{
    public partial class FrmAgregarVehiculo : Form
    {
        private readonly VehiculoController vehiculoController = new VehiculoController();
        public event Action VehiculoAgregado;

        public FrmAgregarVehiculo()
        {
            InitializeComponent(); // NO eliminar
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            // Código para guardar vehículo (usa los controles que existen en Designer)
            if (string.IsNullOrWhiteSpace(txtCodigo.Text) ||
                string.IsNullOrWhiteSpace(txtMarca.Text) ||
                string.IsNullOrWhiteSpace(txtModelo.Text))
            {
                MessageBox.Show("Por favor, completa los campos obligatorios.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Vehiculo nuevo = new Vehiculo
            {
                Codigo = txtCodigo.Text.Trim(),
                Marca = txtMarca.Text.Trim(),
                Modelo = txtModelo.Text.Trim(),
                Tipo = txtTipo.Text.Trim(),
                Anio = (int)numAnio.Value,
                Precio = (double)numPrecio.Value
            };

            if (!vehiculoController.AgregarVehiculo(nuevo))
            {
                MessageBox.Show("Ya existe un vehículo con ese código.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show("Vehículo agregado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VehiculoAgregado?.Invoke();

            txtCodigo.Clear();
            txtMarca.Clear();
            txtModelo.Clear();
            txtTipo.Clear();
            numAnio.Value = DateTime.Now.Year;
            numPrecio.Value = 0;
        }
    }
}
