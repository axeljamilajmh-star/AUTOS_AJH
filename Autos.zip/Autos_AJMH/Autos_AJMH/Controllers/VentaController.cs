﻿using Autos_AJMH.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autos_AJMH.Controllers
{
    public class VentaController
    {
        private readonly List<Venta> Ventas = new List<Venta>();

        public void RegistrarVenta(string codigoVehiculo, double monto)
        {
            Ventas.Add(new Venta
            {
                CodigoVenta = "VEN" + (Ventas.Count + 1).ToString("000"),
                CodigoVehiculo = codigoVehiculo,
                FechaVenta = DateTime.Now,
                Monto = monto
            });
        }

        public List<Venta> ListarVentas()
        {
            return Ventas;
        }

        public double CalcularTotalIngresos()
        {
            double total = 0;
            foreach (var venta in Ventas)
            {
                total += venta.Monto;
            }
            return total;
        }

    }
}
