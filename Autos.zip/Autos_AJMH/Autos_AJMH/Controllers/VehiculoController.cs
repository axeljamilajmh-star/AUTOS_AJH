﻿using Autos_AJMH.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Autos_AJMH.Controllers
{
    public class VehiculoController
    {
        private readonly string rutaArchivo = "vehiculos.json";
        private List<Vehiculo> Inventario;

        public VehiculoController()
        {
            Inventario = CargarVehiculos();

            // Si no hay datos, carga algunos de ejemplo
            if (!Inventario.Any())
            {
                Inventario.AddRange(new List<Vehiculo>
                {
                    new Vehiculo { Codigo = "V001", Marca = "Toyota", Modelo = "Corolla", Anio = 2019, Tipo = "Sedán", Precio = 18000, UnidadesDisponibles = 2, Cilindraje = 1.8, Categoria = "Compacto" },
                    new Vehiculo { Codigo = "V002", Marca = "Honda", Modelo = "Civic", Anio = 2020, Tipo = "Sedán", Precio = 20000, UnidadesDisponibles = 3, Cilindraje = 2.0, Categoria = "Compacto" },
                    new Vehiculo { Codigo = "V003", Marca = "Ford", Modelo = "Ranger", Anio = 2018, Tipo = "Pickup", Precio = 25000, UnidadesDisponibles = 1, Cilindraje = 3.2, Categoria = "Camioneta" }
                });

                GuardarVehiculos();
            }
        }

        // -------------------- CRUD --------------------

        public bool AgregarVehiculo(Vehiculo nuevo)
        {
            // Evitar duplicados
            if (Inventario.Any(v => v.Codigo.Equals(nuevo.Codigo, StringComparison.OrdinalIgnoreCase)))
                return false;

            Inventario.Add(nuevo);
            GuardarVehiculos();
            return true;
        }

        public List<Vehiculo> ListarVehiculos() => Inventario.Where(v => !v.Vendido).ToList();

        public Vehiculo BuscarPorCodigo(string codigo)
        {
            return Inventario.FirstOrDefault(v => v.Codigo.Equals(codigo, StringComparison.OrdinalIgnoreCase));
        }

        public void EliminarVehiculo(string codigo)
        {
            var vehiculo = BuscarPorCodigo(codigo);
            if (vehiculo != null)
            {
                Inventario.Remove(vehiculo);
                GuardarVehiculos();
            }
        }

        // -------------------- FILTROS --------------------

        public List<Vehiculo> FiltrarPorModeloYAño(string modelo, int anio)
        {
            return Inventario
                .Where(v => v.Modelo.Equals(modelo, StringComparison.OrdinalIgnoreCase) && v.Anio == anio)
                .ToList();
        }

        public List<Vehiculo> FiltrarPorPrecioYCategoria(double min, double max, string categoria)
        {
            return Inventario
                .Where(v => v.Precio >= min && v.Precio <= max && v.Categoria.Equals(categoria, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        public void AplicarDescuento(string codigo, double porcentaje)
        {
            var veh = BuscarPorCodigo(codigo);
            if (veh != null && porcentaje <= 10)
            {
                veh.Precio -= veh.Precio * (porcentaje / 100);
                GuardarVehiculos();
            }
        }

        // -------------------- MÉTODOS AUXILIARES --------------------

        public Vehiculo ObtenerMasAntiguo() => Inventario.OrderBy(v => v.Anio).FirstOrDefault();
        public Vehiculo ObtenerMayorCilindraje() => Inventario.OrderByDescending(v => v.Cilindraje).FirstOrDefault();
        public Vehiculo ObtenerMasBarato() => Inventario.OrderBy(v => v.Precio).FirstOrDefault();

        // -------------------- JSON --------------------

        private List<Vehiculo> CargarVehiculos()
        {
            if (!File.Exists(rutaArchivo))
                return new List<Vehiculo>();

            string json = File.ReadAllText(rutaArchivo);
            return JsonConvert.DeserializeObject<List<Vehiculo>>(json) ?? new List<Vehiculo>();
        }

        private void GuardarVehiculos()
        {
            string json = JsonConvert.SerializeObject(Inventario, Formatting.Indented);
            File.WriteAllText(rutaArchivo, json);
        }
    }
}
